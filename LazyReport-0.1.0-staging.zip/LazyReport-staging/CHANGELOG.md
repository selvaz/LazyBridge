# Changelog

## [0.1.0] — extraction from LazyBridge 0.7.9

First release as a standalone package. Extracted verbatim from
`lazybridge.external_tools.report_builder` at LazyBridge `0.7.9`.

### Migrating from `lazybridge.external_tools.report_builder`

Replace every import:

```python
# Before — lazybridge ≤ 0.7.9
from lazybridge.external_tools.report_builder import (
    FragmentBus, fragment_tools, OutlineAssembler, report_tools,
)

# After — install lazybridge-reports, then:
from lazybridge_reports import (
    FragmentBus, fragment_tools, OutlineAssembler, report_tools,
)
```

The public API is otherwise unchanged. Optional-dependency extras moved:

| Old (`lazybridge[...]`)   | New (`lazybridge-reports[...]`) |
|---------------------------|--------------------------------|
| `report`                  | (default install)              |
| `report-charts`           | `charts`                       |
| `report-citations`        | `citations`                    |
| `report-fallback`         | `fallback`                     |
| `pdf`                     | `pdf`                          |

LazyBridge 0.7.9 itself drops these extras — install
`lazybridge-reports` directly.
