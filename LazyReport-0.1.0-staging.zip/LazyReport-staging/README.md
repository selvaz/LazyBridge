# LazyReport

Fragment-based parallel report assembly + classic single-shot report tool
for [LazyBridge](https://github.com/selvaz/LazyBridge).

Extracted from `lazybridge.external_tools.report_builder` at LazyBridge
0.7.9. The split keeps the core LazyBridge install lean (no `weasyprint`,
no `vl-convert`, no Quarto dependency) while letting reporting pipelines
opt into a complete renderer.

## Install

```bash
pip install lazybridge-reports                # core: markdown + jinja2 + bleach
pip install 'lazybridge-reports[charts]'      # add vl-convert + plotly
pip install 'lazybridge-reports[citations]'   # add Crossref + CSL
pip install 'lazybridge-reports[fallback]'    # add WeasyPrint + Pandoc
pip install 'lazybridge-reports[all]'         # everything
```

For the primary render path also install the Quarto CLI separately
(`brew install quarto` or download from <https://quarto.org>).

## Quick start

### Single-shot tool

```python
from lazybridge import Agent
from lazybridge_reports import report_tools

agent = Agent(
    model="anthropic:claude-haiku-4-5",
    tools=report_tools(output_dir="./out"),
)
agent.run("Write a one-page brief on agentic workflows in 2026.")
```

### Parallel-fragment workflow

```python
from lazybridge import Plan, Step, Agent
from lazybridge_reports import FragmentBus, fragment_tools, OutlineAssembler

bus = FragmentBus(
    "daily-news",
    assembler=OutlineAssembler({"1.exec": "Executive Summary", "2.us": "United States"}),
)

researcher = Agent(
    model="anthropic:claude-haiku-4-5",
    tools=fragment_tools(bus=bus, default_section="2.us", step_name="us"),
)

plan = Plan(
    Step(researcher, parallel=True, name="us"),
    Step(lambda env: bus.export(["html", "pdf", "revealjs"], "./out", title="News")),
)
plan.run("Today's news.")
```

## Modules

- `lazybridge_reports.bus` — `FragmentBus` shared bus and emitters
- `lazybridge_reports.assemblers` — `BlackboardAssembler`,
  `OutlineAssembler`, `AssembledReport`
- `lazybridge_reports.fragments` — `Fragment`, `Citation`,
  `Provenance`, `ChartSpec`, `TableSpec`
- `lazybridge_reports.tools` — `report_tools`, `fragment_tools`
- `lazybridge_reports.exporters` — WeasyPrint (PDF) and Quarto
  (HTML/PDF/RevealJS/DOCX) back-ends
- `lazybridge_reports.charts` — Vega-Lite and Plotly renderers
- `lazybridge_reports.citations` — Crossref enrichment + CSL fallback

## License

MIT. See `LICENSE`.
